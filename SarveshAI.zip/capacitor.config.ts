import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.sarvesh.ai',
  appName: 'SARVESH AI',
  webDir: 'dist',
};

export default config;
