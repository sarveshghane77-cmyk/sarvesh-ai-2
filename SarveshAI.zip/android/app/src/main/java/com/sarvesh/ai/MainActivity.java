package com.sarvesh.ai;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
